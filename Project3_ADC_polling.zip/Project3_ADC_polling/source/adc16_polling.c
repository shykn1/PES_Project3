/**
*	@file 			adc16_polling.c
*	@brief 		ADC functions for this project
*					Using ADC polling to test the ADC configuration (clock, gpio, referenceVoltageSource)
*
*	@author 		Linfeng Li
*	@date 			Apr 22 2019 
*	@version  	1.0
*/


#include "fsl_debug_console.h"
#include "board.h"
#include "fsl_adc16.h"

#include "pin_mux.h"
#include "clock_config.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define DEMO_ADC16_BASE ADC0
#define DEMO_ADC16_CHANNEL_GROUP 0U
#define DEMO_ADC16_USER_CHANNEL 0U /*PTE20, ADC0_SE0 */


/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
volatile uint32_t tick=0;
/*******************************************************************************
 * Code
 ******************************************************************************/

/*!
 * @systick for output
 */
void SysTick_Handler(void)  {                               /* SysTick interrupt Handler.*/
	tick++;
}

/*!
 * @brief Main function
 */
int main(void)
{
    adc16_config_t adc16ConfigStruct;
    adc16_channel_config_t adc16ChannelConfigStruct;
    adc16_hardware_average_mode_t adc16_average = kADC16_HardwareAverageCount32;
    uint32_t pre_tick=0,current_tick=0;;
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();
    SysTick_Config(240);
    PRINTF("\r\nADC16 polling Example.\r\n");

    /*
     * adc16ConfigStruct.referenceVoltageSource = kADC16_ReferenceVoltageSourceVref;
     * adc16ConfigStruct.clockSource = kADC16_ClockSourceAsynchronousClock;
     * adc16ConfigStruct.enableAsynchronousClock = true;
     * adc16ConfigStruct.clockDivider = kADC16_ClockDivider8;
     * adc16ConfigStruct.resolution = kADC16_ResolutionSE12Bit;
     * adc16ConfigStruct.longSampleMode = kADC16_LongSampleDisabled;
     * adc16ConfigStruct.enableHighSpeed = false;
     * adc16ConfigStruct.enableLowPower = false;
     * adc16ConfigStruct.enableContinuousConversion = false;
     */
	 
    PRINTF("bus clock %d\r\n", CLOCK_GetBusClkFreq());
    ADC16_GetDefaultConfig(&adc16ConfigStruct);
    adc16ConfigStruct.clockDivider = kADC16_ClockDivider2;
    adc16ConfigStruct.clockSource = kADC16_ClockSourceAlt0;
    adc16ConfigStruct.resolution = kADC16_ResolutionSE16Bit;
    adc16ChannelConfigStruct.channelNumber = DEMO_ADC16_USER_CHANNEL;
	   adc16ChannelConfigStruct.enableInterruptOnConversionCompleted = false;
	   adc16ChannelConfigStruct.enableDifferentialConversion = false;
    ADC16_Init(DEMO_ADC16_BASE, &adc16ConfigStruct);
    ADC16_SetHardwareAverage(DEMO_ADC16_BASE,adc16_average);
    ADC16_EnableHardwareTrigger(DEMO_ADC16_BASE, false); /* Make sure the software trigger is used. */
    if (kStatus_Success == ADC16_DoAutoCalibration(DEMO_ADC16_BASE))
    {
        PRINTF("ADC16_DoAutoCalibration() Done.\r\n");
    }
    else
    {
        PRINTF("ADC16_DoAutoCalibration() Failed.\r\n");
    }
    PRINTF("Press any key to get user channel's ADC value ...\r\n");




    while (1)
    {
        /*
         When in software trigger mode, each conversion would be launched once calling the "ADC16_SetChannelConfig()"
         function, which works like writing a conversion command and executing it. For another channel's conversion,
         just to change the "channelNumber" field in channel's configuration structure, and call the
         "ADC16_SetChannelConfig() again.
        */

        ADC16_SetChannelConfig(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP, &adc16ChannelConfigStruct);
        while (0U == (kADC16_ChannelConversionDoneFlag &
                      ADC16_GetChannelStatusFlags(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP)))
        {
        }
        current_tick = tick;
        PRINTF("%d,%d\r\n", ADC16_GetChannelConversionValue(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP), current_tick- pre_tick);
        pre_tick=tick;

    }
}
