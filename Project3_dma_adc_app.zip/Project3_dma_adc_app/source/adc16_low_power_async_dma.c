/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "fsl_debug_console.h"
#include "fsl_smc.h"
#include "fsl_pmc.h"
#include "fsl_adc16.h"
#include "fsl_dmamux.h"
#include "board.h"
#include "fsl_lptmr.h"
#include "stdlib.h"
#include "stdint.h"
#include "fsl_dma.h"

#include "pin_mux.h"
#include "clock_config.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define DEMO_ADC16_BASEADDR ADC0
#define DEMO_ADC16_CHANNEL_GROUP 0U
#define DEMO_ADC16_CHANNEL 26U


#define DEMO_ADC16_BASE ADC0
#define DEMO_ADC16_USER_CHANNEL 0U /*PTE20, ADC0_SE0 */



#define ADC16_RESULT_REG_ADDR (uint32_t)(&ADC0->R[0]) /* Get ADC16 result register address */

#define DEMO_DMA_BASEADDR DMA0
#define DEMO_DMA_IRQ_ID DMA0_IRQn
#define DEMO_DMA_IRQ_HANDLER_FUNC DMA0_IRQHandler
#define DEMO_DMA_CHANNEL 0U
#define DEMO_DMA_ADC_SOURCE kDmaRequestMux0ADC0

#define DEMO_DMAMUX_BASEADDR DMAMUX0

#define DEMO_LPTMR_BASE LPTMR0

#define LED_INIT() LED_RED_INIT(LOGIC_LED_OFF)
#define LED_TOGGLE() LED_RED_TOGGLE()

#define DEMO_LPTMR_COMPARE_VALUE 100U /* Low Power Timer interrupt time in miliseconds */
#define DEMO_ADC16_SAMPLE_COUNT 256U   /* The ADC16 sample count */

#define BIT_ONE_MASK (0x1U)
#define DECAY_COEFF (0.95)
/*******************************************************************************
 * Prototypes
 ******************************************************************************/


/*!
 * @brief Initialize the ADCx for HW trigger.
 *
 */
static void ADC16_Configuration(void);

/*!
 * @brief Process ADC values.
 *
 */
static void ProcessSampleData(void);

/*!
 * @brief Initialize the DMA for async mode.
 *
 */
static void DMA_Configuration(void);

/*!
 * @brief switch the buffer index
 *
 */
static void Buffer_alter(uint8_t* buffer_index);


/*******************************************************************************
 * Variables
 ******************************************************************************/
uint8_t buffer_sel_DMA;
uint8_t buffer_sel_process;
static int32_t g_adc16SampleDataArray[2][DEMO_ADC16_SAMPLE_COUNT]; /* ADC value array */
static uint32_t g_peakADCValue = 0U;                              /* current peak ADC value */
dma_handle_t g_DMA_Handle;                                       /* Dma handler */
dma_transfer_config_t g_transferConfig;                          /* Dma transfer config */
volatile bool DMA_done = 0;
adc16_config_t adc16ConfigStruct;
adc16_channel_config_t adc16ChannelConfigStruct;
adc16_hardware_average_mode_t adc16_average = kADC16_HardwareAverageCount32;
volatile uint32_t tick=0;
/*******************************************************************************
 * Code
 ******************************************************************************/

static void Buffer_alter(uint8_t* buffer_index){
	*buffer_index = BIT_ONE_MASK &(~(*buffer_index));
}

static void ADC16_Configuration(void)
{

    /*
    * Initialization ADC for
    * 16bit resolution, interrupt mode, hw trigger enabled.
    * normal convert speed, VREFH/L as reference,
    * disable continuous convert mode.
    */
    PRINTF("bus clock %d\r\n", CLOCK_GetBusClkFreq());
	ADC16_GetDefaultConfig(&adc16ConfigStruct);
	adc16ConfigStruct.clockDivider = kADC16_ClockDivider2;//ADC clk: 12MHz
	adc16ConfigStruct.clockSource = kADC16_ClockSourceAlt0;
	adc16ConfigStruct.resolution = kADC16_ResolutionSE16Bit;
	adc16ConfigStruct.enableContinuousConversion= true;
	adc16ChannelConfigStruct.channelNumber = DEMO_ADC16_USER_CHANNEL;
	adc16ChannelConfigStruct.enableInterruptOnConversionCompleted = false;
	adc16ChannelConfigStruct.enableDifferentialConversion = false;
	ADC16_Init(DEMO_ADC16_BASE, &adc16ConfigStruct);
	ADC16_SetHardwareAverage(DEMO_ADC16_BASE,adc16_average);
	ADC16_EnableHardwareTrigger(DEMO_ADC16_BASE, false); /* Make sure the software trigger is used. */
   if (kStatus_Success == ADC16_DoAutoCalibration(DEMO_ADC16_BASE))
   {
	   PRINTF("ADC16_DoAutoCalibration() Done.\r\n");
   }
   else
   {
	   PRINTF("ADC16_DoAutoCalibration() Failed.\r\n");
   }
   //PRINTF("Press any key to get user channel's ADC value ...\r\n");

    /* Configure channel 0 */
    //ADC16_SetChannelConfig(DEMO_ADC16_BASEADDR, DEMO_ADC16_CHANNEL_GROUP, &adcChnConfig);
    /* Enable hardware trigger  */
    //ADC16_EnableHardwareTrigger(DEMO_ADC16_BASEADDR, true);
    /* Enable DMA */
    ADC16_EnableDMA(DEMO_ADC16_BASEADDR, true);
}

static void DMA_Configuration(void)
{
    /* Configure DMAMUX */
    DMAMUX_Init(DEMO_DMAMUX_BASEADDR);
    DMAMUX_SetSource(DEMO_DMAMUX_BASEADDR, DEMO_DMA_CHANNEL, DEMO_DMA_ADC_SOURCE); /* Map ADC source to channel 0 */
    DMAMUX_EnableChannel(DEMO_DMAMUX_BASEADDR, DEMO_DMA_CHANNEL);

    DMA_Init(DEMO_DMA_BASEADDR);
    DMA_CreateHandle(&g_DMA_Handle, DEMO_DMA_BASEADDR, DEMO_DMA_CHANNEL);
    DMA_PrepareTransfer(&g_transferConfig, (void *)ADC16_RESULT_REG_ADDR, sizeof(uint32_t),
                        (void *)g_adc16SampleDataArray[buffer_sel_DMA], sizeof(uint32_t), sizeof(g_adc16SampleDataArray[buffer_sel_DMA]),
                        kDMA_PeripheralToMemory);
    /* Setup transfer */
    DMA_SetTransferConfig(DEMO_DMA_BASEADDR, DEMO_DMA_CHANNEL, &g_transferConfig);
    /* Enable interrupt when transfer is done. */
    DMA_EnableInterrupts(DEMO_DMA_BASEADDR, DEMO_DMA_CHANNEL);
    /* Enable async DMA request. */
    //DMA_EnableAsyncRequest(DEMO_DMA_BASEADDR, DEMO_DMA_CHANNEL, true);
    /* Forces a single read/write transfer per request. */
    DMA_EnableCycleSteal(DEMO_DMA_BASEADDR, DEMO_DMA_CHANNEL, true);
    /* Enable transfer. */
    DMA_StartTransfer(&g_DMA_Handle);
    /* Enable IRQ. */
    NVIC_EnableIRQ(DEMO_DMA_IRQ_ID);
}

static void ProcessSampleData(void)
{
    uint32_t i = 0U;
    uint32_t adc_value;
    uint8_t decay_flag=1;
    /* Get average adc value */
    for (i = 0; i < DEMO_ADC16_SAMPLE_COUNT; i++)
    {
    	adc_value=g_adc16SampleDataArray[buffer_sel_process][i];
    	if(adc_value < 0){
    		PRINTF("Something wrong\r\n");
    	}
        if(adc_value>g_peakADCValue){
        	g_peakADCValue = adc_value;
        	decay_flag = 0;
        }
    }
    if(decay_flag)
    	g_peakADCValue = (int32_t)((float)(DECAY_COEFF)*((float)g_peakADCValue));
    /* Reset old value */
    for (i = 0; i < DEMO_ADC16_SAMPLE_COUNT; i++)
    {
        g_adc16SampleDataArray[buffer_sel_process][i] = -1;
    }
}



void DEMO_DMA_IRQ_HANDLER_FUNC(void)
{
	adc16ChannelConfigStruct.channelNumber = 31U;
	ADC16_SetChannelConfig(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP, &adc16ChannelConfigStruct);
    /* Clear transaction done interrupt flag */
    DMA_ClearChannelStatusFlags(DEMO_DMA_BASEADDR, DEMO_DMA_CHANNEL, kDMA_TransactionsDoneFlag);


    /* Setup transfer */
    DMA_done = 1;
}

/*!
 * @systick for output
 */
void SysTick_Handler(void)  {                               /* SysTick interrupt Handler.*/
	tick++;
}


int main(void)
{
	buffer_sel_DMA=0;
	buffer_sel_process=0;
	uint32_t pre_tick=0;
    /* Initialize hardware */
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();
    /* Initialize Led */
    LED_INIT();
    SysTick_Config(240);
    PRINTF("ADC LOW POWER ASYNC DMA DEMO\r\n");

    /* Set to allow entering vlps mode */
    //SMC_SetPowerModeProtection(SMC, kSMC_AllowPowerModeVlp);
    /* Initialize ADC */
    ADC16_Configuration();
    /* Initialize DMA */
    DMA_Configuration();
    /* Initialize the HW trigger source */
    //LPTMR_Configuration();
    /* Initialize SIM for ADC hw trigger source selection */
    //BOARD_ConfigTriggerSource();
    //ADC16_SetChannelConfig(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP, &adc16ChannelConfigStruct);
    ADC16_SetChannelConfig(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP, &adc16ChannelConfigStruct);
    while (1)
    {
        /* Toggle led */
        LED_TOGGLE();
        if(DMA_done){
        	DMA_done=0;


			Buffer_alter(&buffer_sel_DMA);
		    DMA_EnableCycleSteal(DEMO_DMA_BASEADDR, DEMO_DMA_CHANNEL, true);
		    DMA_PrepareTransfer(&g_transferConfig, (void *)ADC16_RESULT_REG_ADDR, sizeof(uint32_t),
		                        (void *)g_adc16SampleDataArray[buffer_sel_DMA], sizeof(uint32_t), sizeof(g_adc16SampleDataArray[buffer_sel_DMA]),
		                        kDMA_PeripheralToMemory);
			DMA_SetTransferConfig(DEMO_DMA_BASEADDR, DEMO_DMA_CHANNEL, &g_transferConfig);
			adc16ChannelConfigStruct.channelNumber = DEMO_ADC16_USER_CHANNEL;
			ADC16_SetChannelConfig(DEMO_ADC16_BASE, DEMO_ADC16_CHANNEL_GROUP, &adc16ChannelConfigStruct);
			/* Process ADC value */
			ProcessSampleData();
			Buffer_alter(&buffer_sel_process);
			PRINTF("peak :%d,%d\r\n", g_peakADCValue,tick-pre_tick);
			pre_tick =tick;
        }
    }
}
