/**
*	@file 			db_look_up.c
*	@brief 		Transfer ADC signal value into dbfs value 
*
*	@author 		Tim Chien
*	@date 			Apr 27 2019 
*	@version  	1.0
*/


#include "db_lookup.h"

int look_up_table [NUM_OF_LOOK_UP] ={1000,1009,1018,1027,1037,1046,1056,1065,1075,1085,1094,1104,1114,1125,1135,1145,1155,1166,1176,1187,1198,1209,1220,1231,1242,1253,1265,1276,1288,1299,1311,1323,1335,1347,1359,1372,1384,1396,1409,1422,1435,1448,1461,1474,1488,1501,1515,1528,1542,1556,1570,1585,1599,1613,1628,1643,1658,1673,1688,1703,1719,1734,1750,1766,1782,1798,1814,1831,1847,1864,1881,1898,1915,1933,1950,1968,1986,2004,2022,2040,2059,2077,2096,2115,2134,2154,2173,2193,2213,2233,2253,2274,2294,2315,2336,2357,2379,2400,2422,2444,2466,2488,2511,2534,2557,2580,2603,2627,2651,2675,2699,2723,2748,2773,2798,2824,2849,2875,2901,2927,2954,2981,3008,3035,3063,3090,3118,3147,3175,3204,3233,3262,3292,3322,3352,3382,3413,3444,3475,3507,3538,3570,3603,3635,3668,3702,3735,3769,3803,3838,3873,3908,3943,3979,4015,4051,4088,4125,4163,4200,4238,4277,4316,4355,4394,4434,4474,4515,4556,4597,4639,4681,4723,4766,4809,4853,4897,4941,4986,5031,5077,5123,5169,5216,5264,5311,5359,5408,5457,5507,5556,5607,5658,5709,5761,5813,5866,5919,5973,6027,6081,6136,6192,6248,6305,6362,6420,6478,6537,6596,6656,6716,6777,6838,6900,6963,7026,7090,7154,7219,7285,7351,7417,7484,7552,7621,7690,7760,7830,7901,7973,8045,8118,8191,8266,8341,8416,8493,8570,8647,8726,8805,8885,8965,9046,9129,9211,9295,9379,9464,9550,9637,9724,9812,9901,9991};

/**
*	@brief 		transfer ratio to dbfs with look up table
*	
*	@param		float ratio		the ratio of  maximum value of ADC to the ADC output value ( maximum_ADC / output_ADC )
*/
float look_up_db(float ratio){
    int ten_power_count = 0;
    int half_index = 2;
    int base_index = 0;
    int current_index = NUM_OF_LOOK_UP/half_index;
    while(1==1)
    {
        if (ratio <= 10) break;
        ratio /=  10;
        ten_power_count ++;
        //printf("ten_power_count : %d rtio : %f \n",ten_power_count,ratio);
    }
    if(ratio != 10){
        uint32_t ratio_int32= ratio*1000;
        //printf("%d\n",ratio_int32);
        ratio *= 1000;
        //printf("%d\n",look_up_table[128]);
        while(half_index <= NUM_OF_LOOK_UP){
            //printf("half : %d, base : %d, index : %d\n",half_index,base_index,current_index);
            //printf("%4.0f  %d ",ratio,look_up_table[current_index]);
            if(ratio < look_up_table[current_index])
            {
                //do nothing
                //printf("  go down\n");
            }
            else if(ratio > look_up_table[current_index])
            {
                base_index = NUM_OF_LOOK_UP/half_index+base_index;
                //printf("  go up\n");
            }
            else if(ratio == look_up_table[current_index])
            {
                //printf("  stop\n");
                return  (ten_power_count+RESOLUATION_OF_LOOK_UP*(current_index))*-20;
            }
            half_index *= 2;
            current_index = NUM_OF_LOOK_UP/half_index+base_index;
            
        }
        //printf("%d %d %d\n",look_up_table[current_index],look_up_table[current_index+1],current_index);
        current_index = (look_up_table[current_index]+look_up_table[current_index+1])/2 < ratio ? current_index+1 : current_index;
        //printf("%d %d %d\n",look_up_table[current_index],ratio,current_index);
        return  (ten_power_count+current_index*RESOLUATION_OF_LOOK_UP)*-20;
    }else{
        return (ten_power_count+1)*-20;
    }
}

/**
*	@brief 		transfer ADC input data to dbfs signal value
*
*	@param		uint16_t input_data		2 bytes data from ADC
*/
float ratio_to_db(uint16_t input_data){
    float input_data_f = (float)(input_data);
    float ratio = DB_BASE_MAX/input_data_f;
    //printf("ratio : %f\n",ratio);
    float result = look_up_db(ratio);
    return result;
}

