/**
*	@file 			db_lookup.h
*	@brief 		dB convertor functions for this project
*	
*
*	@author 		
*	@date 			March 30 2019 
*	@version  	1.0
*/
#ifndef  __DB_LOOKUP__
#define __DB_LOOKUP__
#include "stdint.h"

#define DB_BASE_MAX 65535.0
#define NUM_OF_LOOK_UP  256
#define RESOLUATION_OF_LOOK_UP  0.0039



float look_up_db(float ratio);
float ratio_to_db(uint16_t input_data);


#endif
